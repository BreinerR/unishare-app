import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from 'react-native';
import { useAuth } from '../../context/AuthContext';
import Colors, { SICILY_PALETTE } from '../../constants/colors';
import GoogleAccountSelectorModal from '../../components/auth/GoogleAccountSelectorModal';
import { validatePassword } from '../../utils/validators';

export default function RegisterScreen({ navigation }) {
  const { register, loginWithGoogle } = useAuth();

  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [ubicacionGeneral, setUbicacionGeneral] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showGoogleModal, setShowGoogleModal] = useState(false);

  const handleGoogleRegister = () => {
    setErrorMessage('');
    setShowGoogleModal(true);
  };

  const handleAccountSelectedFromModal = async (account) => {
    setShowGoogleModal(false);
    try {
      setGoogleLoading(true);
      setErrorMessage('');

      await loginWithGoogle({
        id: account.id,
        googleId: account.googleId || account.id,
        uid_auth: account.uid_auth || account.id,
        email: account.email,
        name: account.name,
        password: account.password,
        photoUrl: account.photoUrl || account.picture,
        ubicacion_general: ubicacionGeneral.trim() || account.ubicacion_general || 'Sector Comunitario / Por definir'
      });
    } catch (error) {
      console.error('[GoogleRegister Error]:', error);
      setErrorMessage(error.message || 'Error al autenticar con la cuenta de Google seleccionada.');
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!nombre.trim() || !correo.trim() || !password) {
      setErrorMessage('Por favor completa todos los campos obligatorios.');
      return;
    }

    // Validación estricta de contraseña (longitud mínima 6, letras y números)
    const passValidation = validatePassword(password);
    if (!passValidation.isValid) {
      setErrorMessage(passValidation.message);
      return;
    }

    try {
      setLoading(true);
      setErrorMessage('');
      await register({
        nombre: nombre.trim(),
        correo: correo.trim(),
        password,
        ubicacion_general: ubicacionGeneral.trim() || 'Sector Comunitario General'
      });
    } catch (error) {
      setErrorMessage(error.message || 'Error al crear la cuenta comunitaria. Intenta nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.keyboardContainer}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer} keyboardShouldPersistTaps="handled">
        {/* Cabecera con Verde Oscuro Protagonista */}
        <View style={styles.header}>
          <Text style={styles.appTitle}>Crea tu Cuenta</Text>
          <View style={styles.communityPill}>
            <Text style={styles.communityPillText}>Comunidad de Préstamo e Intercambio</Text>
          </View>
          <Text style={styles.appSubtitle}>
            Forma parte de la red colaborativa de tu barrio, conjunto o empresa
          </Text>
        </View>

        {/* Tarjeta de Formulario */}
        <View style={styles.card}>
          {errorMessage ? (
            <View style={styles.errorBanner}>
              <Text style={styles.errorText}>{errorMessage}</Text>
            </View>
          ) : null}

          {/* Acceso Rápido con Google */}
          <TouchableOpacity
            style={styles.googleButton}
            onPress={handleGoogleRegister}
            disabled={googleLoading || loading}
            activeOpacity={0.85}
          >
            {googleLoading ? (
              <ActivityIndicator color={Colors.primary} size="small" />
            ) : (
              <View style={styles.googleButtonContent}>
                <View style={styles.googleIconBadge}>
                  <Text style={styles.googleIconText}>G</Text>
                </View>
                <Text style={styles.googleButtonText}>Registrarme con Google</Text>
              </View>
            )}
          </TouchableOpacity>

          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>o completa tus datos</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Nombre Completo *</Text>
            <TextInput
              style={styles.input}
              placeholder="Ej. Camila Morales"
              placeholderTextColor={Colors.textMuted}
              value={nombre}
              onChangeText={(text) => {
                setNombre(text);
                if (errorMessage) setErrorMessage('');
              }}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Correo Electrónico (personal o laboral) *</Text>
            <TextInput
              style={styles.input}
              placeholder="tu.correo@ejemplo.com"
              placeholderTextColor={Colors.textMuted}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              value={correo}
              onChangeText={(text) => {
                setCorreo(text);
                if (errorMessage) setErrorMessage('');
              }}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Contraseña *</Text>
            <View style={styles.passwordWrapper}>
              <TextInput
                style={[styles.input, styles.passwordInput]}
                placeholder="Mínimo 6 caracteres (letras y números)"
                placeholderTextColor={Colors.textMuted}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                value={password}
                onChangeText={(text) => {
                  setPassword(text);
                  if (errorMessage) setErrorMessage('');
                }}
              />
              <TouchableOpacity
                style={styles.eyeBtn}
                onPress={() => setShowPassword(!showPassword)}
                activeOpacity={0.7}
              >
                <Text style={styles.eyeIconText}>{showPassword ? '👁️' : '🔒'}</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.passwordHintText}>
              Debe contener al menos 6 caracteres e incluir letras y números.
            </Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Ubicación General (Barrio / Sector / Empresa / Conjunto)</Text>
            <TextInput
              style={styles.input}
              placeholder="Ej. Sector Parque Central / Conjunto Los Álamos"
              placeholderTextColor={Colors.textMuted}
              value={ubicacionGeneral}
              onChangeText={setUbicacionGeneral}
            />
            <View style={styles.privacyNoticeContainer}>
              <Text style={styles.privacyNoticeIcon}>🛡️</Text>
              <Text style={styles.privacyNoticeText}>
                🛡️ Tu zona o sector se comparte únicamente como referencia para entregas. Tu dirección exacta se mantiene siempre privada.
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={[styles.primaryButton, loading && styles.buttonDisabled]}
            onPress={handleRegister}
            disabled={loading || googleLoading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color={Colors.textOnPrimary} />
            ) : (
              <Text style={styles.primaryButtonText}>Crear Cuenta Comunitaria</Text>
            )}
          </TouchableOpacity>

          <View style={styles.footerLinkContainer}>
            <Text style={styles.footerText}>¿Ya tienes una cuenta en la red? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={styles.linkText}>Inicia Sesión</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Selector Modal Inteligente y Sincronizado de Cuentas Google */}
      <GoogleAccountSelectorModal
        visible={showGoogleModal}
        onClose={() => setShowGoogleModal(false)}
        onSelectAccount={handleAccountSelectedFromModal}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  keyboardContainer: {
    flex: 1,
    backgroundColor: SICILY_PALETTE.azulProfundo // #1D59BB Identidad de marca
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
    paddingVertical: 32
  },
  header: {
    alignItems: 'center',
    marginBottom: 20
  },
  appTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center'
  },
  communityPill: {
    backgroundColor: SICILY_PALETTE.amarilloCalido,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 16,
    marginTop: 6,
    marginBottom: 6
  },
  communityPillText: {
    color: SICILY_PALETTE.textoOscuro,
    fontSize: 11,
    fontWeight: '800'
  },
  appSubtitle: {
    fontSize: 13,
    color: '#EBF3FE',
    marginTop: 2,
    textAlign: 'center',
    paddingHorizontal: 12,
    lineHeight: 18,
    opacity: 0.95
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 22,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.18,
    shadowRadius: 16,
    elevation: 8
  },
  errorBanner: {
    backgroundColor: '#FDEDED',
    borderColor: '#F5C2C7',
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 14
  },
  errorText: {
    color: Colors.error,
    fontSize: 13,
    textAlign: 'center'
  },
  googleButton: {
    height: 48,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1
  },
  googleButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10
  },
  googleIconBadge: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: '#EA4335',
    alignItems: 'center',
    justifyContent: 'center'
  },
  googleIconText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14
  },
  googleButtonText: {
    color: Colors.textPrimary,
    fontSize: 15,
    fontWeight: '600'
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 12
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.borderLight
  },
  dividerText: {
    marginHorizontal: 10,
    fontSize: 12,
    color: Colors.textMuted
  },
  inputGroup: {
    marginBottom: 12
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginBottom: 4
  },
  input: {
    height: 46,
    backgroundColor: '#F7FAF8',
    borderColor: Colors.border,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    fontSize: 14,
    color: Colors.textPrimary
  },
  passwordWrapper: {
    position: 'relative',
    justifyContent: 'center'
  },
  passwordInput: {
    paddingRight: 44
  },
  eyeBtn: {
    position: 'absolute',
    right: 12,
    height: 46,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4
  },
  eyeIconText: {
    fontSize: 16
  },
  passwordHintText: {
    fontSize: 11,
    color: Colors.textMuted,
    marginTop: 4
  },
  privacyNoticeContainer: {
    flexDirection: 'row',
    backgroundColor: SICILY_PALETTE.amarilloSuave,
    borderRadius: 10,
    padding: 10,
    marginTop: 8,
    borderWidth: 1,
    borderColor: 'rgba(254, 189, 25, 0.4)'
  },
  privacyNoticeIcon: {
    marginRight: 6,
    fontSize: 14
  },
  privacyNoticeText: {
    flex: 1,
    fontSize: 11,
    color: '#6B4E00',
    lineHeight: 15,
    fontWeight: '500'
  },
  primaryButton: {
    height: 50,
    backgroundColor: SICILY_PALETTE.amarilloCalido, // #FEBD19 Acción Principal
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 14,
    shadowColor: SICILY_PALETTE.amarilloCalido,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    elevation: 3
  },
  buttonDisabled: {
    opacity: 0.7
  },
  primaryButtonText: {
    color: SICILY_PALETTE.textoOscuro,
    fontSize: 16,
    fontWeight: '800'
  },
  footerLinkContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 16
  },
  footerText: {
    fontSize: 13,
    color: Colors.textSecondary
  },
  linkText: {
    fontSize: 13,
    fontWeight: '800',
    color: SICILY_PALETTE.azulProfundo
  }
});
